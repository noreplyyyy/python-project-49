### Hexlet tests and linter status:
[![Actions Status](https://github.com/noreplyyyy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/noreplyyyy/python-project-49/actions)
<a href="https://codeclimate.com/github/noreplyyyy/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ae622f279bc49ff6815b/maintainability" /></a>
https://asciinema.org/a/jI1Vb92M909QklLZ4Litlmu92